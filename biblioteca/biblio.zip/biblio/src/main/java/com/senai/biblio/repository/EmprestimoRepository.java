
package com.senai.biblio.repository;

import com.senai.biblio.entity.Emprestimo;
import com.senai.biblio.entity.Estudante;
import com.senai.biblio.entity.Livro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmprestimoRepository extends JpaRepository<Emprestimo,Long>{
    
    Emprestimo findByEstudante(Estudante estudante);
    Emprestimo findByLivro(Livro livro);
}
