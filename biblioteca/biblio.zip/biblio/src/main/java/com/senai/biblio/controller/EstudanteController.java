package com.senai.biblio.controller;

import com.senai.biblio.entity.Estudante;
import com.senai.biblio.service.EstudanteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/biblio/estudante")
public class EstudanteController {

    @Autowired
    private EstudanteService estudanteService;
    
    
    @PostMapping("/estudante")
    public ResponseEntity<Long> incluirNovoEstudante(@RequestBody Estudante estudante) {
        Long idEst = estudanteService.incluirEstudante(estudante);
        if (idEst != null) {
            return new ResponseEntity<>(idEst, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/{idEstudante}")
    public ResponseEntity<Long> excluirEstudante(@PathVariable("idEstudante") Long idEstudante) {
        if (estudanteService.excluirEstudante(idEstudante)) {
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping
    public ResponseEntity<List<Estudante>> listarEstudantes() {
        List<Estudante> listEst = estudanteService.listarEstudantes();
        if (!listEst.isEmpty()) {
            return new ResponseEntity<>(listEst, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/{idEstudante}")
    public ResponseEntity<Estudante> consultarEstudantePorId(@PathVariable("idEstudante") Long idEstudante) {
        Estudante estudante = estudanteService.consultaEstudantePorId(idEstudante);
        if (estudante != null) {
            return new ResponseEntity<>(estudante, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/matricula/{matricula}")
    public ResponseEntity<Estudante> consultarEstudantePorMatricula(@PathVariable("matricula") Long matricula) {
        Estudante estudante = estudanteService.consultaEstudantePorMatricula(matricula);
        if (estudante != null) {
            return new ResponseEntity<>(estudante, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping
    public ResponseEntity<Boolean> alterarEstudante(@RequestBody Estudante estudante) {
        if (estudanteService.alterarEstudante(estudante)) {
            return new ResponseEntity<>(true, HttpStatus.OK);
        }
        return new ResponseEntity<>(false, HttpStatus.NOT_FOUND);
    }
}