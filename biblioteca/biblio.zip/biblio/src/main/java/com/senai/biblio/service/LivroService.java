package com.senai.biblio.service;

import com.senai.biblio.entity.Livro;
import com.senai.biblio.repository.LivroRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LivroService {
    
    @Autowired
    private LivroRepository livroRepository;
    
    public Long incluirLivro(Livro livro){
        if(livro.getTitulo() == null || livro.getTitulo().isEmpty()){
            return null;
        }
        if(livro.getEditora() == null || livro.getEditora().isEmpty()){
            return null;
        }
        if(livro.getAno() == null || livro.getAno() <= 0){
            return null;
        }
        return livroRepository.save(livro).getIdLivro();
    }
    
    public boolean excluirLivro(Long idLivro){
        if(livroRepository.findById(idLivro).isPresent()){
            livroRepository.deleteById(idLivro);
            return true;
        }
        return false;
    }
        
    public Livro consultaLivroPorId(Long idLivro){
        return livroRepository.findById(idLivro).orElse(null);
    }
    
    public List<Livro> listarLivros(){
        return livroRepository.findAll();
    }
    
    public boolean alterarLivro(Livro livro){
        if(livro.getTitulo() == null || livro.getTitulo().isEmpty()){
            return false;
        }
        if(livro.getEditora() == null || livro.getEditora().isEmpty()){
            return false;
        }
        if(livro.getAno() == null || livro.getAno() <= 0){
            return false;
        }
        
        Livro livroBD = livroRepository.getReferenceById(livro.getIdLivro());
        if(livroBD != null){
            livroBD.setTitulo(livro.getTitulo());
            livroBD.setAutor(livro.getAutor());
            livroBD.setEditora(livro.getEditora());
            livroBD.setAno(livro.getAno());
            livroRepository.save(livroBD);
            return true;
        }
        return false;
    }
}
