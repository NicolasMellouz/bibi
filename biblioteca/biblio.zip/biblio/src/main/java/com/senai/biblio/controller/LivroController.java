package com.senai.biblio.controller;

import com.senai.biblio.entity.Livro;
import com.senai.biblio.service.LivroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/biblio/livro")
public class LivroController {

    @Autowired
    private LivroService livroService;

    @GetMapping("/{idLivro}")
    public ResponseEntity<Livro> consultarLivroPorId(@PathVariable("idLivro") Long idLivro) {
        Livro livro = livroService.consultaLivroPorId(idLivro);
        if (livro != null) {
            return new ResponseEntity<>(livro, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PostMapping("/")
    public ResponseEntity<Long> incluirLivro(@RequestBody Livro livro) {
        Long idLivro = livroService.incluirLivro(livro);
        if (idLivro != null) {
            return new ResponseEntity<>(idLivro, HttpStatus.CREATED);
        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    @DeleteMapping("/{idLivro}")
    public ResponseEntity<Void> excluirLivro(@PathVariable("idLivro") Long idLivro) {
        boolean excluido = livroService.excluirLivro(idLivro);
        if (excluido) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/")
    public ResponseEntity<List<Livro>> listarLivros() {
        List<Livro> livros = livroService.listarLivros();
        return new ResponseEntity<>(livros, HttpStatus.OK);
    }

    @PutMapping("/")
    public ResponseEntity<Void> alterarLivro(@RequestBody Livro livro) {
        boolean alterado = livroService.alterarLivro(livro);
        if (alterado) {
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }
}
